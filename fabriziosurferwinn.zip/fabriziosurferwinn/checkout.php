<?php
include 'layoust/head.php';
if (!isset($_SESSION['carrito'])) {
  header('Location: .index.php');
}
$arreglo = $_SESSION['carrito'];

?> 
  
  <form action="./php/insertarpedido.php" name="form" id="form" method="post">
  <?php 
    if(isset($_POST['c_fname'])){
      $nombre = $_POST['c_fname'];
      $apellido = $_POST['c_lname'];
      $dni = $_POST['c_dni'];
      $c_signo = $_POST['c_signo'];
      $country = $_POST['country'];
      $c_department = $_POST['c_department'];
      $c_department2 = $_POST['c_department2'];
      $c_district = $_POST['c_district'];
      $c_address = $_POST['c_address'];
      $c_address2 = $_POST['c_address2'];
      $c_email_address = $_POST['c_email_address'];
      $c_phone = $_POST['c_phone'];
      $terminos = $_POST['terminos'];
      

      $campos = array();

      if($nombre == ""){
        array_push($campos, "Completar el Campo Nombre.");
      }
      if($apellido == ""){
        array_push($campos, "Completar el Campo Apellido.");
      }
      if($dni == ""){
        array_push($campos, "Completar el Campo DNI.");
      }
      if($c_signo == ""){
        array_push($campos, "Completar el Campo Signo.");
      }
      if($country == "Perú"){
        array_push($campos, "Solo Envios a todo el Perú.");
      }
      if($c_department == ""){
        array_push($campos, "Completar el Campo Departamento.");
      }
      if($c_department2 == ""){
        array_push($campos, "Completar el Campo Departamento.");
      }
      if($c_district == ""){
        array_push($campos, "Completar el Campo Distrito.");
      }
      if($c_address == ""){
        array_push($campos, "Completar el Campo Direccion.");
      }
      if($c_email_address == "" || strpos($email, "@") === false){
        array_push($campos, "Ingresa un Correo Electronico Válido.");
      }

      

      if(count($campos)>0){
        echo "<div class='error'>";
        for($i = 0; $i < count($campos); $i++){
          echo "<li>".campos[$i]."</li>";
        }
      }else{
        echo "<div class='correcto'>Datos Correctos";
      }
      echo "</div>";
    }
  ?>
    <div class="site-section">
      <div class="container">
        <div class="row mb-5">
          <div class="col-md-10 offset-md-1">
            <div class="process-wrap">
              <div class="process text-center active">
                <p><span>01</span></p>
                <h3>Bolsa<a></h3>
              </div>
              <div class="process text-center active">
                <p><span>02</span></p>
                <h3>Checkout</h3>
              </div>
              <div class="process text-center">
                <p><span>03</span></p>
                <h3>Orden Completa</h3>
              </div>
            </div>
          </div>
        </div>
        <img class="OJO" src="images/OJO FSW.png" width="90px">
        <br>
        <div class="row">
          <div class="col-md-6 mb-5 mb-md-0">
            <h2 class="h3 mb-3 text-black">DETALLES DE LA COMPRA</h2>
            <div class="p-3 p-lg-5 border">
              <div class="form-group row">
                <div class="col-md-6">
                  <label for="c_fname" class="text-black">Nombre <span class="text-danger">*</span></label>
                  <input type="text" class="form-control border-black" id="c_fname" name="c_fname">
                  <i class="fas fa-check-circle"></i>
                  <i class="fas fa-exclamation-circle"></i>
                  <small>Error Message</small>
                </div>
                <div class="col-md-6">
                  <label for="c_lname" class="text-black">Apellido <span class="text-danger">*</span></label>
                  <input type="text" class="form-control border-black" id="c_lname" name="c_lname">
                  <i class="fas fa-check-circle"></i>
                  <i class="fas fa-exclamation-circle"></i>
                  <small>Error Message</small>
                </div>
              </div>

              <div class="form-group row">
                <div class="col-md-6">
                  <label for="c_dni" class="text-black">DNI <span class="text-danger">*</span></label>
                  <input type="text" class="form-control border-black" id="c_dni" name="c_dni">
                  <i class="fas fa-check-circle"></i>
                  <i class="fas fa-exclamation-circle"></i>
                  <small>Error Message</small>
                </div>
              

                <div class="col-md-6">
                  <label for="c_signo" class="text-black">Signo <span class="text-danger">*</span></label>
                  <input type="text" class="form-control border-black" id="c_signo" name="c_signo">
                  <i class="fas fa-check-circle"></i>
                  <i class="fas fa-exclamation-circle"></i>
                  <small>Error Message</small>
                </div>
              </div>



              <div class="form-group row">
                <div class="col-md-12">
                <label for="country" class="text-black">País <span class="text-danger">*</span></label>
                <input type="text" id="country" class="form-control border-black plain-text" name="country" value="Perú" readonly="true">
                <small>Error Message</small>
              </div>
              </div>

              <div class="form-group row">
                <div class="col-md-12">
                  <label for="c_department" class="text-black">Departamento</label>
                  <select class="form-control border-black" id="c_department" name="c_department">
                    <option value="">Selecciona tu Departamento</option>  
                    <option value="1">Amazonas</option>
                    <option value="2">Áncash</option> 
                    <option value="3">Apurímac</option> 
                    <option value="4">Arequipa</option> 
                    <option value="5">Ayacucho</option>  
                    <option value="6">Cajamarca</option>
                    <option value="7">Cuzco</option> 
                    <option value="8">Huancavelica</option> 
                    <option value="9">Huánuco</option> 
                    <option value="10">Ica</option>  
                    <option value="11">Junín</option>  
                    <option value="12">La Libertad</option>
                    <option value="13">Lambayeque</option> 
                    <option value="14">Lima</option> 
                    <option value="15">Loreto</option> 
                    <option value="16">Madre de Dios</option> 
                    <option value="17">Moquegua</option>  
                    <option value="18">Pasco</option>  
                    <option value="19">Piura</option>
                    <option value="20">Puno</option> 
                    <option value="21">San Martín</option> 
                    <option value="22">Tacna</option> 
                    <option value="23">Tumbes</option>  
                    <option value="23">Ucayali</option>  
                  </select>
                  <i class="fas fa-check-circle"></i>
                  <i class="fas fa-exclamation-circle"></i>
                  <small>Error Message</small>
                </div>
              </div>
              <br>
              <div class="form-group row">
                <div class="col-md-12">
                <input type="text" class="form-control border-black" placeholder="Si no aparece tu Departamento detallalo aquí" id="c_department2" name="c_department2">
                  <small>Error Message</small>
                </div>
              </div>

              <div class="form-group row">
                <div class="col-md-12">
                  <label for="c_district" class="text-black">Distrito <span class="text-danger">*</span></label>
                  <input type="text" class="form-control border-black" id="c_district" name="c_district" placeholder="Distrito">
                  <i class="fas fa-check-circle"></i>
                  <i class="fas fa-exclamation-circle"></i>
                  <small>Error Message</small>
                </div>
              </div>

              <div class="form-group row">
                <div class="col-md-12">
                  <label for="c_address" class="text-black">Dirección <span class="text-danger">*</span></label>
                  <input type="text" class="form-control border-black" id="c_address" name="c_address" placeholder="Dirección">
                  <i class="fas fa-check-circle"></i>
                  <i class="fas fa-exclamation-circle"></i>
                  <small>Error Message</small>
                </div>
              </div>

              <div class="form-group row">
                <div class="col-md-12">
                  <label for="c_address" class="text-black">Dirección Exacta <span class="text-danger">*</span></label>
                  <input type="text" class="form-control border-black" id="c_address2" name="c_address2">
                  <i class="fas fa-check-circle"></i>
                  <i class="fas fa-exclamation-circle"></i>
                  <small>Error Message</small>
                </div>
              </div>

              <div class="form-group row mb-5">
                <div class="col-md-6">
                  <label for="c_email_address" class="text-black">Correo <span class="text-danger">*</span></label>
                  <input type="text" class="form-control border-black" id="c_email_address" name="c_email_address">
                  <i class="fas fa-check-circle"></i>
                  <i class="fas fa-exclamation-circle"></i>
                  <small>Error Message</small>
                </div>
                <div class="col-md-6">
                  <label for="c_phone" class="text-black">Número de Celular <span class="text-danger">*</span></label>
                  <input type="text" class="form-control border-black" id="c_phone" name="c_phone" placeholder="Número de Celular">
                  <i class="fas fa-check-circle"></i>
                  <i class="fas fa-exclamation-circle"></i>
                  <small>Error Message</small>
                </div>
              </div>

              <div class="form-group">
                <label for="c_create_account" class="text-black" data-toggle="collapse" href="#create_an_account" role="button" aria-expanded="false" aria-controls="create_an_account"><input type="checkbox" value="1" id="c_create_account"> Crea una cuenta?</label>
                <div class="collapse" id="create_an_account">
                  <div class="py-2">
                    <p class="mb-3">Cree una cuenta ingresando la información a continuación. Si es un cliente recurrente, inicie sesión en la parte superior de la página.</p>
                    <div class="form-group">
                      <label for="c_account_password" class="text-black">Contraseña de la cuenta</label>
                      <input type="password" class="form-control border-black" id="c_account_password" name="c_account_password" placeholder="">
                    </div>
                  </div>
                </div>
              </div>

            </div>
          </div>
          <div class="col-md-6">

            <!--<div class="row mb-5">
              <div class="col-md-12">
                <h2 class="h3 mb-3 text-black">Código promocional</h2>
                <div class="p-3 p-lg-5 border">
                  
                  <label for="c_code" class="text-black mb-3">Ingrese su código de cupón si tiene uno</label>
                  <div class="input-group w-75">
                    <input type="text" class="form-control border-black" id="c_code" placeholder="Coupon Code" aria-label="Coupon Code" aria-describedby="button-addon2">
                    <div class="input-group-append">
                      <button class="btn block-black border-black text-white btn-sm" type="button" id="button-addon2">Aplicar</button>
                    </div>
                  </div>

                </div>
              </div>
            </div>-->
            
            <div class="row mb-5">
              <div class="col-md-12">
                <h2 class="h3 mb-3 text-black">INFORMACIÓN DEL PEDIDO</h2>
                <div class="p-3 p-lg-5 border">
                  <table class="table site-block-order-table mb-5">
                    <thead>
                      <th>Producto</th>
                      <th>Cantidad</th>
                      <th>Total</th>
                    </thead>
                    <tbody>
                      <?php 
                      $total=0;
                      for ($i=0; $i < count($arreglo); $i++) { 
                        $total = $total +($arreglo[$i]['Precio']*$arreglo[$i]['Cantidad']);
                      ?>
                      <tr>
                        <td><?php echo $arreglo[$i]['Nombre'];?></td>
                        <td class="text-center">x<?php echo $arreglo[$i]['Cantidad'];?></td>
                        <td>S/.<?php echo number_format($arreglo[$i]['Precio'],2,'.','');?></td>
                      </tr>
                      <?php } ?>
                      <tr>
                        <td class="text-black font-weight-bold"><strong>Subtotal: </strong></td>
                        <td></td>
                        <td class="text-black">S/.<?php echo number_format($total,2,'.','');?></td>
                      </tr>


                      <tr>
                        <td class="text-black font-weight-bold"><strong>Total del Pedido:</strong></td>
                        <td></td>
                        <td class="text-black font-weight-bold"><strong>S/.<?php echo number_format($total,2,'.','');?></strong></td>
                      </tr>
                    <table>
                      <tbody>
                      <tr>
                        <td>
                          <div class="col-md-12">
                              <input type="checkbox" name="terminos" id="terminos"> He leído y estoy de acuerdo con los<a href="PoliticasPrivacidad" class="text-black"> Acepto los Terminos y Condiciones</a>
                          </div>
                          <small class="text-center">Error Message</small>
                        </td>
                      </tr>
                      </tbody>
                    </table>
                    </tbody>
                  </table>
                  <br>
                  <div class="form-group">
                    <button class="btn block-black border-black text-white btn-lg py-3 btn-block" name="btn" onclick="veri()" type="submit">Realizar pedido</button>
                  </div>

                </div>
              </div>
            </div>

          </div>
        </div>
        <!-- </form> -->
      </div>
    </div>
    </form>

    <?php include 'layoust/foot.php'; ?>
<script src="js/formulario.js"></script>

<script>
  let terminos = document.getElementById('terminos');
  function veri(){
    if(terminos.checked){

    }else{
      alert('Acepta los Terminos y Condiciones');
    }
  }
</script>