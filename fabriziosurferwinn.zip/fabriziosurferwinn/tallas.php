<?php include 'layoust/head.php'; ?> 

    <div class="centrador">
      <img class="responsive" src="images/MEDIDAS Y DETALLES WEB.png">
      <img class="responsive1" src="images/MEDIDAS Y DETALLES MOVIL.png">
    </div>
    <br>

    <div class="header__menu">
      <i class="icon-instagram"></i>
            <ul>
                <p>Sigueme en</p>
                <li><a href="https://instagram.com/fsw.universo?r=nametag">@fsw.universo</a></li>
            </ul>
        </div>

    <div class="gallery-container">
      <div class="gallery-item">
        <img id="gallery-item-index" src="images/FINAL UNO.png">
      </div>
      <div class="gallery-item">
        <img id="gallery-item-index" src="images/FINAL DOS.png">
      </div>
      <div class="gallery-item">
        <img id="gallery-item-index" src="images/FINAL TRES.png">
      </div>
      <div class="gallery-item">
        <img id="gallery-item-index" src="images/FINAL CUATRO.png">
      </div>
    </div>

<?php include('./layoust/foot.php'); ?> 