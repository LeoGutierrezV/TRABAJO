<?php 
	include './conexion.php';

	$enviado = true;
	$Archivos = array($_FILES["imagen"],$_FILES["imagen2"],$_FILES["imagen3"],$_FILES["imagen4"]);

    $imagen_final = array(null);
foreach ($Archivos as $ar){

    $target_dir = "./../galeria/";
    $target_file = basename($ar["name"]);
    $target_file = $target_dir.$target_file;
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

    // verificar si es una imagen o no
    if($enviado) {
    $check = getimagesize($ar["tmp_name"]);
    if($check !== false) {
        echo "El archivo es una imagen - " . $check["mime"] . ".";
        $uploadOk = 1;
    } else {
        echo "El archivo no es un imagen.";
        $uploadOk = 0;
    }
    }

    // chequea si ya existe la imagen
    if (file_exists($target_file)) {
        echo "La Imagen ya existe.";
        $uploadOk = 0;
    }


    // verificar los formatos
    if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
    && $imageFileType != "gif" ) {
    //header ("Location: ../admin/productos.php?error=Solo se adminte JPG, JPEG, PNG y GIF ");
    $uploadOk = 0;
    }

    // verifica si hay un error en la subida de datos
    if ($uploadOk == 0) {
    //header ("Location: ../admin/productos.php?error=No se ha podido subir el archivo.");

    } else {
        if(move_uploaded_file($ar["tmp_name"], $target_file)) {
            echo "El archivo ". htmlspecialchars( basename( $ar["name"])). " Se ha subido exitosamente.";
            array_push($imagen_final,$target_file);

        } else {
            // header ("Location: ../admin/productos.php?error=Ha ocurrido un error en la subida del archivo.");

        }
    }
}

$imagen1 ="";
$imagen2 ="";
$imagen3 ="";
$imagen4 ="";

$imagen1 = $imagen_final[1] ? $imagen_final[1] : "";
$imagen2 = $imagen_final[2] ? $imagen_final[2] : "";
$imagen3 = $imagen_final[3] ? $imagen_final[3] : "";
$imagen4 = $imagen_final[4] ? $imagen_final[4] : "";




//=====================================================================================================================/ 
if(isset($_POST['nombre'])&& isset($_POST['descripcion']) && isset($_POST['precio'])
	 && isset($_POST['inventario'])&& isset($_POST['categoria']) && isset($_POST['talla'])&& isset($_POST['color'])  ){

		$conexion->query("insert into productos
				 (nombre,descripcion,precio,talla,color,inventario,id_categoria,imagen,imagen2,imagen3,imagen4) values
				 (
				 	'".$_POST['nombre']."',
				 	'".$_POST['descripcion']."',
				 	".$_POST['precio'].",
				 	'".$_POST['talla']."',
				 	'".$_POST['color']."',
				 	'".$_POST['inventario']."',
					'".$_POST['categoria']."',
                    '".$imagen1."',
					'".$imagen2."',
                    '".$imagen3."',
					'".$imagen4."'
				 )

				 ")or die($conexion->error);
				header("Location: ../admin/productos.php?success");

	 }

?>