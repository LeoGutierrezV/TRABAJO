<?php
  if (!isset($_SESSION['datos_login'])) {
    header("Location: ../index.php");
  }
  $arregloUsuario = $_SESSION['datos_login'];
  if ($arregloUsuario['nivel']!= 'admin') {
  header("Location: ../index.php");
  }
?>
<!-- /.content-wrapper -->
  <footer class="main-footer">
    <strong>Copyright &copy; 2021 fabriziosurferwinn</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      <b>Version</b> 3.1.0
    </div>
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->