<?php 
    include 'php/conexion.php';
    include 'layoust/head.php';
    if(!isset($_GET['id_venta'])){
        header("Location: ./");
    }
    $datos = $conexion->query("select
            ventas.*,
            usuario.nombre,usuario.telefono,usuario.email
            from ventas
            inner join usuario on ventas.id_usuario = usuario.id
            where ventas.id=".$_GET['id_venta'])or die($conexion->error);
    $datosUsuario = mysqli_fetch_row($datos);
    $datos2 = $conexion->query("select * from envios where id_venta=".$_GET['id_venta'])or die($conexion->error);
    $datosEnvio = mysqli_fetch_row($datos2);

    $datos3 = $conexion->query("select productos_venta.*,
            productos.nombre as nombre_producto, productos.imagen
            from productos_venta inner join productos on productos_venta.id_producto = productos.id
            where id_venta =".$_GET['id_venta'])or die($conexion->error);
?>  

    <div class="site-section">
      <div class="container">
        <img class="OJO" src="images/OJO FSW.png" width="90px">
        <div class="row">
          <div class="col-md-12">
            <h2 class="h3 mb-3 text-black Franklin">DETALLES DE PEDIDO</h2>
          </div>
          <div class="col-md-7 ">

            <form action="#" method="post">
              
              <div class="p-3 p-lg-5 border border-black">
                <div class="form-group row">
                  <div class="col-md-12">
                    <label class="verpedidodetalles1">Venta #<?php echo $_GET['id_venta'];?></label>
                  </div>
                </div>

                <div class="form-group row">
                  <div class="col-md-12">
                    <label class="verpedidodetalles1">Nombre: <?php echo $datosUsuario[4];?></label>
                  </div>
                </div>

                <div class="form-group row">
                  <div class="col-md-12">
                    <label class="verpedidodetalles1">Email: <?php echo $datosUsuario[6];?></label>
                  </div>
                </div>
                
                <div class="form-group row">
                  <div class="col-md-12">
                    <label class="verpedidodetalles1">Telefono/Celular: <?php echo $datosUsuario[5];?></label>
                  </div>
                </div>

                <div class="form-group row">
                  <div class="col-md-12">
                    <label class="verpedidodetalles1">País: <?php echo $datosEnvio[1];?></label>
                  </div>
                </div>

                <div class="form-group row">
                  <div class="col-md-12">
                    <label class="verpedidodetalles1">Departamento: <?php echo $datosEnvio[2];?></label>
                  </div>
                </div>

                <div class="form-group row">
                  <div class="col-md-12">
                    <label class="verpedidodetalles1">Distrito: <?php echo $datosEnvio[4];?></label>
                  </div>
                </div>

                <div class="form-group row">
                  <div class="col-md-12">
                    <label class="verpedidodetalles1">Dirección: <?php echo $datosEnvio[5];?></label>
                  </div>
                </div>

              </div>
            </form>
          </div>
          <div class="col-md-5 ml-auto text-center">
          <?php 
            while($f = mysqli_fetch_array($datos3)){
          ?>
            <div class="p-4 border mb-3 border-black">
            <img src="./images/<?php echo $f['imagen'];?>" width="125px">
              <span class="d-block EYELEVATION"><?php echo $f['nombre_producto'];?></span><br>
              <span class="d-block verpedidodetalles">Cantidad: <?php echo $f['cantidad'];?></span>
              <span class="d-block verpedidodetalles">Precio: S/<?php echo $f['precio'];?></span>
              <span class="d-block verpedidodetalles">SubTotal: S/<?php echo $f['subtotal'];?></span>
            </div>
        <?php }?>
            <h4 class="verpedidodetalles">Total: S/<?php echo $datosUsuario[2];?></h4>
          </div>
        </div>
      </div>
    </div>

    <div class="header__menu">
      <a href="https://instagram.com/fsw.universo?r=nametag"><i class="icon-instagram"></i></a>
            <ul>
                <p>Sigueme en</p>
                <li><a href="https://instagram.com/fsw.universo?r=nametag">@fsw.universo</a></li>
            </ul>
        </div>

    <div class="gallery-container">
      <div class="gallery-item">
        <img id="gallery-item-index" src="images/item-1-1-1.jpg">
      </div>
      <div class="gallery-item">
        <img id="gallery-item-index" src="images/item-1-1-2.jpg">
      </div>
      <div class="gallery-item">
        <img id="gallery-item-index" src="images/item-1-1-3.jpg">
      </div>
      <div class="gallery-item">
        <img id="gallery-item-index" src="images/item-1-1-4.jpg">
      </div>
    </div>

<?php include('./layoust/foot.php'); ?> 