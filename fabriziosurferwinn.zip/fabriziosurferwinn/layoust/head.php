<?php 
  session_start();
  include "./php/conexion.php";
  
?>
<!DOCTYPE html>
<html>
<head>
	<title>fabriziosurferwinn</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1-0, minium-scale=1.0">
  <link rel="shortcut icon" type="ico/icon" href="images/OJO.png"/>
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <link rel="stylesheet" type="text/css" href="css/estilos.css">
	<link rel="stylesheet" href="fonts/icomoon/style.css">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
  <link rel="stylesheet" href="css/magnific-popup.css">
  <link rel="stylesheet" href="./fond.css">
</head>
<body>
	<div class="site-wrap">
    <header class="site-navbar" role="banner">
      <div class="site-navbar-top">
        <div class="container">
          <div class="row align-items-center">
            <div class="col-6 col-md-4 order-2 order-md-1 site-search-icon text-left">
              <form action="./busqueda2.0.php" class="site-block-top-search" method="GET">
                <span class="icon icon-search"></span>
                <input type="text" class="form-control border-0" placeholder="Search" name="texto">
              </form>
            </div>
            <div class="col-12 mb-3 mb-md-0 col-md-4 order-1 order-md-2 text-center">
              <div class="site-logo">
                <a href="Inicio" class="border-none"><img class="text-center" id="colorlib-logo" src="images/LOGO FSW.png" height="auto" width="250"></a>
              </div>
            </div>

            <div class="col-6 col-md-4 order-3 order-md-3 text-right">
              <div class="site-top-icons">
                <ul><!--<a href="Session">  <span class="fas fa-sign-out-alt"></span>-->
                  <li>
                    <div class="dropdown">
                      <span class="icon-person" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"></span>
                      <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuButton">
                        <a class="dropdown-item" href="Session">Iniciar Session</a>
                        <a class="dropdown-item" href="#">Perfil <span class="fas fa-user"></span></a>
                        <a class="dropdown-item" href="./php/cerrar_sesion.php">Cerrar Session <span class="fas fa-sign-out-alt"></span></a>
                      </div>
                    </div>
                  </li>
                  <li><a href="#"><span class="icon-heart-o"></span></a></li>
                  <li>

                    <div class="dropdown">
                    <span class="site-cart" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                      <span class="icon-shopping-bag"></span>
                      <span class="block-black count">
                        <?php
                          if(isset($_SESSION['carrito'])){
                            echo count($_SESSION['carrito']);
                          }else{
                            echo 0;
                          }
                        ?>  
                      </span>
                        </span>
                    
                      <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuButton">
                        <div class="ml-auto text-center contenedor-scroll">
                        <?php
                          $total=0;
                            if(isset($_SESSION['carrito'])){
                              $arregloCarrito =$_SESSION['carrito'];
                              for ($i=0; $i < count($arregloCarrito) ; $i++) { 
                                $total =$total + ($arregloCarrito[$i]['Precio']* $arregloCarrito[$i]['Cantidad']);
                          ?>
                              <div class="p-4 border mb-3 border-black">
                                <img class="border border-black" src="./images/<?php echo $arregloCarrito[$i]['Imagen']?>" alt="<?php echo $arregloCarrito[$i]['Nombre']?>" width="80px"><p></p>
                                  <h6 class="EYELEVATION"><?php echo $arregloCarrito[$i]['Nombre']?></h6>
                                  <h6 class="text-black">Cantidad: </p>
                                  <h6 class="text-black">Precio: S/<?php echo $arregloCarrito[$i]['Precio']?></h6>
                              </div>
                            <?php } }?>
                            <h6 class="text-black">Total: S/<?php echo $total;?></h6>
                        </div>
                        <div class="space-min"></div>
                        <a class="dropdown-item text-center button-comprar" href="cart.php">Ver Carrito <span class="icon-shopping-bag"></span></a>
                      </div>
                    </div>     
                  </li> 
                  <li class="d-inline-block d-md-none ml-md-0"><span id="btn-menu" class="icon-menu"></span></li>
                </ul>
              </div> 
            </div>
          </div>
        </div>
      </div>
      <nav class="main-nav" role="navigation" id="main-nav">
        <div class="container">
          <ul class="menu text-center">
            <li class="menu_item"><a class="menu__link" href="index.php">INICIO</a></li>
            <li class="menu_item"><a class="menu__link" href="tienda.php">TIENDA</a></li>
            <li class="menu_item"><a class="menu__link" href="about.php">MARCA</a></li>
            <li class="menu_item"><a class="menu__link" href="tallas.php">TALLAS</a></li>
          </ul>
        </div>
      </nav>
      <div class="space"></div>
    </header>
