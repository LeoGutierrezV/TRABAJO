<footer class="colorlib-footer">
      <div class="colorlib-widget-1">
        <img id="colorlib-logo-2" src="images/OJO.png" alt="logo" height="50" width="85">

        <ul class="colorlib-social-icons">
          <li><a href="https://www.facebook.com/FabrizioSW"><i class="icon-facebook"></i></a></li>
          <li><a href="https://instagram.com/fsw.universo?r=nametag"><i class="icon-instagram"></i></a></li>
          <li><a href="https://www.youtube.com/channel/UCNkn3KZKxLTXxc34F3Fr5aQ"><i class="icon-youtube"></i></a></li>
          <li><a href="https://www.behance.net/fabriziosw"><i class="icon-behance2"></i></a></li>
          <li><a href="Inicio"><i class="icon-earth"></i></a></li>
        </ul>
      </div>
 

      <div class="colorlib-widget">
        <h2>POLITICAS DE PRIVACIDAD</h2>
        <p>
          <ul class="colorlib-footer-links">
            <li><a class="text-white" href="PoliticasPrivacidad">Políticas de Privacidad</a></li>
          </ul>
        </p>
      </div>
      <div class="colorlib-widget">
        <h2>INFORMACIÓN</h2>
        <p>
          <ul class="colorlib-footer-links">
            <li><a class="text-white" href="PreguntasFrecuentes">Preguntas Frecuentes</a></li>
          </ul>
        </p>
      </div>

      <!--<div class="colorlib-widget">
        <h2>COLECCIONES</h2>
        <ul class="colorlib-footer-links">
          <li><a href="blog.html">FabrizioSurferWinn</a></li>
        </ul>
      </div>-->


      <div class="colorlib-widget-1">
        <br>
        <br>
          <ul class="colorlib-social-icons-1">
            <li><a href="https://www.facebook.com/FabrizioSW"><i class="icon-facebook"></i></a></li>
            <li><a href="https://instagram.com/fsw.universo?r=nametag"><i class="icon-instagram"></i></a></li>
            <li><a href="https://www.youtube.com/channel/UCNkn3KZKxLTXxc34F3Fr5aQ"><i class="icon-youtube"></i></a></li>
            <li><a href="https://www.behance.net/fabriziosw"><i class="icon-behance2"></i></a></li>
            <li><a href="Inicio"><i class="icon-earth"></i></a></li>
          </ul>
      </div>
      <div class="copy">
        <p>COPYRIGHT 2021 &copy; fabriziosurferwinn <span class="color-span"></span></p>
      </div>

    </footer>

  </div>
  
  <script type="text/javascript" src="js/main.js" ></script>
  <script src="js/jquery-3.3.1.min.js"></script>
  <script src="js/jquery-ui.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/main2.0.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/magnific-popup-options.js"></script>
  <script src="js/preguntasFrecuentes.js"></script>
  <script src="js/categorias.js"></script>

  <script>
    $(document).ready(function(){
      $(".btnEliminar").click(function(event){
        event.preventDefault();
        var id = $(this).data('id');
          var boton = $(this);
        $.ajax({
          method:'POST',
          url:'./php/eliminarCarrito.php',
          data:{
            id:id
          }
        }).done(function(respuesta){
          boton.parent('td').parent('tr').remove();
        });
      });
      $(".txtCantidad").keyup(function(){
        var cantidad = $(this).val();
        var precio = $(this).data('precio');
        var id = $(this).data('id');
        incrementar(cantidad,precio,id);
      });
      $(".btnIncrementar").click(function(){
        var precio = $(this).parent('div').parent('div').find('input').data('precio');
        var id = $(this).parent('div').parent('div').find('input').data('id');
        var cantidad = $(this).parent('div').parent('div').find('input').val();
        incrementar(cantidad,precio,id);
      });
      function incrementar(cantidad,precio,id){
        var mult = parseFloat(cantidad)*parseFloat(precio);
        $(".cant"+id).text("S/."+mult);
        $.ajax({
          method:'POST',
          url:'./php/actualizar.php',
          data:{
            id:id,
            cantidad:cantidad
          }
        }).done(function(respuesta){
        });
      }
    });
  </script>

  <script>
    $(document).ready(function(){
      $("#button-addon2").click(function(){
        var codigo = $("#c_code").val();
        $.ajax({
          url:"./php/validarcodigo.php",
          data:{
            codigo:codigo
          },
          method:'POST'
        }).done(function(respuesta){
          alert(respuesta);
        })
      });
    });
  </script>
    
  </body>
</html>