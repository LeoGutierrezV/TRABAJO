<?php include 'layoust/head.php'; ?> 

    <div class="site-blocks-cover" style="background-image: url(images/GIFWEB.gif);" data-aos="fade">
      
    </div>

    <!--<div class="site-section site-section-sm site-blocks-1">
      <div class="container">
        <div class="row">
          <div class="col-md-6 col-lg-4 d-lg-flex mb-4 mb-lg-0 pl-4" data-aos="fade-up" data-aos-delay="">
            <div class="icon mr-4 align-self-start">
              <span class="icon-truck"></span>
            </div>
            <div class="text">
              <h2 class="text-uppercase">Free Shipping</h2>
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus at iaculis quam. Integer accumsan tincidunt fringilla.</p>
            </div>
          </div>
          <div class="col-md-6 col-lg-4 d-lg-flex mb-4 mb-lg-0 pl-4" data-aos="fade-up" data-aos-delay="100">
            <div class="icon mr-4 align-self-start">
              <span class="icon-refresh2"></span>
            </div>
            <div class="text">
              <h2 class="text-uppercase">Free Returns</h2>
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus at iaculis quam. Integer accumsan tincidunt fringilla.</p>
            </div>
          </div>
          <div class="col-md-6 col-lg-4 d-lg-flex mb-4 mb-lg-0 pl-4" data-aos="fade-up" data-aos-delay="200">
            <div class="icon mr-4 align-self-start">
              <span class="icon-help"></span>
            </div>
            <div class="text">
              <h2 class="text-uppercase">Customer Support</h2>
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus at iaculis quam. Integer accumsan tincidunt fringilla.</p>
            </div>
          </div>
        </div>
      </div>
    </div>-->
    <div class="space"></div>
    <div class="header__menu">
      <a href="https://instagram.com/fsw.universo?r=nametag"><i class="icon-instagram"></i></a>
            <ul>
                <p>Sigueme en</p>
                <li><a href="https://instagram.com/fsw.universo?r=nametag">@fsw.universo</a></li>
            </ul>
        </div>

    <div class="gallery-container">
      <div class="gallery-item">
        <img id="gallery-item-index" src="images/FINAL UNO.png">
      </div>
      <div class="gallery-item">
        <img id="gallery-item-index" src="images/FINAL DOS.png">
      </div>
      <div class="gallery-item">
        <img id="gallery-item-index" src="images/FINAL TRES.png">
      </div>
      <div class="gallery-item">
        <img id="gallery-item-index" src="images/FINAL CUATRO.png">
      </div>
    </div>

<?php include('./layoust/foot.php'); ?> 