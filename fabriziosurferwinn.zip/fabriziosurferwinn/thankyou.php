<?php
 include 'layoust/head.php';
 include './php/conexion.php';


// Cargamos Requests y Culqi PHP
include_once dirname(__FILE__).'/Requests/library/Requests.php';
Requests::register_autoloader();
include_once dirname(__FILE__).'/culqi-php/lib/culqi.php';

// Configurar tu API Key y autenticación
$SECRET_KEY = "sk_test_ed65d82ad369932e";
$culqi = new Culqi\Culqi(array('api_key' => $SECRET_KEY));

  $charge = $culqi->Charges->create(
 array(
     "amount" => 1500,
     "currency_code" => "PEN",
     "email" => "test_charge@culqi.com",
     "source_id" => "id del objeto Token o id del objeto Card"
   )
);

?> 
    <div id="centrador" data-aos="fade">
		<img class="responsive" src="images/AGRADECIMIENTOS.png">
	  </div>
    

    <div class="site-section">
      <div class="container">
        <div class="row">
          <div class="col-md-12 text-center">
            <p><a href="verpedido.php?id_venta=<?php echo $id_venta;?>" class="btn btn-sm block-black border-black text-white">Ver Pedido</a></p>
          </div>
          <div class="col-md-12 text-center">
            <p><a href="index.php" class="btn btn-sm block-black border-black text-white">Regresar al Inicio</a></p>
          </div>
        </div>
      </div>
    </div>

    <?php include 'layoust/foot.php'; ?> 