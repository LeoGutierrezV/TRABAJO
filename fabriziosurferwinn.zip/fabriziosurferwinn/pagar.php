
<?php

include 'php/conexion.php';
include 'layoust/head.php';
    if(!isset($_GET['id_venta'])){
        header("Location: ./");
    }
    $datos = $conexion->query("select
            ventas.*,
            usuario.nombre,usuario.telefono,usuario.email
            from ventas
            inner join usuario on ventas.id_usuario = usuario.id
            where ventas.id=".$_GET['id_venta'])or die($conexion->error);
    $datosUsuario = mysqli_fetch_row($datos);
    $datos2 = $conexion->query("select * from envios where id_venta=".$_GET['id_venta'])or die($conexion->error);
    $datosEnvio = mysqli_fetch_row($datos2);

    $datos3 = $conexion->query("select productos_venta.*,
            productos.nombre as nombre_producto, productos.imagen, productos.descripcion
            from productos_venta inner join productos on productos_venta.id_producto = productos.id
            where id_venta =".$_GET['id_venta'])or die($conexion->error);


?>
    </script>
	<script src="https://checkout.culqi.com/js/v3"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>



<div class="site-section">
      <div class="container">
        <div class="row row-pb-lg">
					<div class="col-md-10 offset-md-1">
						<div class="process-wrap">
							<div class="process text-center active">
								<p><span>01</span></p>
								<h3>Bolsa<a></h3>
							</div>
							<div class="process text-center active">
								<p><span>02</span></p>
								<h3>Checkout</h3>
							</div>
							<div class="process text-center">
								<p><span>03</span></p>
								<h3>Orden Completa</h3>
							</div>
						</div>
					</div>
				</div>
        <div class="row">
          <div class="col-md-6 mb-5 mb-md-0">
            <h2 class="h3 mb-3 text-black">DETALLES DE PEDIDO</h2>
                <div class="p-3 p-lg-5 border">
                  <table class="table site-block-order-table mb-5">
                    <tbody>

                    <tr>
                        <td class="text-black font-weight-bold">Número de Pedido: <?php echo $_GET['id_venta'];?></td>
                    </tr>
                      
                    <tr>
                        <td class="text-black font-weight-bold">Nombre: <?php echo $datosUsuario[6];?></td>
                    </tr>

                    <tr>
                        <td class="text-black font-weight-bold">Email: <?php echo $datosUsuario[8];?></td>
                    </tr>

                    <tr>
                        <td class="text-black font-weight-bold">Telefono/Celular: <?php echo $datosUsuario[7];?></td>
                    </tr>

                    <tr>
                        <td class="text-black font-weight-bold">País: <?php echo $datosEnvio[1];?></td>
                    </tr>

                    <tr>
                        <td class="text-black font-weight-bold">Departamento: <?php echo $datosEnvio[2];?></td>
                    </tr>

                    <tr>
                        <td class="text-black font-weight-bold">Distrito: <?php echo $datosEnvio[4];?></td>
                    </tr>

                    <tr>
                        <td class="text-black font-weight-bold ">Dirección: <?php echo $datosEnvio[5];?></td>
                    </tr>


                    </tbody>
                  </table>

            </div>
          </div>
          <div class="col-md-6">
            
            <div class="row mb-5">
              <div class="col-md-12">
                <h2 class="h3 mb-3 text-black">INFORMACIÓN DEL PEDIDO</h2>
                <div class="p-3 p-lg-5 border">
                  <table class="table site-block-order-table mb-5">
                    <thead>
                      <th>Producto</th>
                      <th>Categoria</th>
                      <th>Cantidad</th>
                      <th>Precio</th>
                    </thead>
                    <tbody>
                      <?php 
			            while($f = mysqli_fetch_array($datos3)){
			          ?>
                      <tr>
                        <td id="nombre_productoFinal"><?php echo $f['nombre_producto'];?></td>
                        <td id="nombre_descripcionFinal"><?php echo $f['descripcion'];?></td>
                        <td class="text-center">x<?php echo $f['cantidad'];?></td>
                        <td id="nombre_precioFinal">S/<?php echo number_format($f['precio'],2,'.','');?></td>
                      </tr>
                      <?php } ?>
                      <tr>
                        <td class="text-black font-weight-bold"><strong>Total del Pedido:</strong></td>
                        <td></td>
                        <td></td>
                        <td class="text-black font-weight-bold"><strong>S/<?php echo number_format($datosUsuario[2],2,'.','');?></strong></td>
                      </tr>
                    </tbody>
                  </table>

                <div id="accordion">

                  <div class="card">
                    <div class="card-header" id="headingOne">
                      <h5 class="mb-0 text-center">
                        <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseUno" aria-expanded="false" aria-controls="collapseDos">
                          VISA
                        </button>
                      </h5>
                    </div>
                    <div id="collapseUno" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
                      <div class="card-body">

                        <p class="col-md-12"><small>Realiza la compra presionando Pagar
                          Si deseas cambiar de medio de pago presiona Cancelar</small></p>
                          <div class="text-center">
                            <form action="/insertarpago.php" method="POST">
                              <button class="btn btn-primary block-black border-black" type="button" name="" id="buyButton" value="COMPRAR" data-producto="1">Pagar con Culqi</button>
                            </form>
                        </div>

                      </div>
                    </div>
                  </div>

                  <div class="card">
                    <div class="card-header" id="headingThree">
                      <h5 class="mb-0 text-center">
                        <button class="btn btn-link collapsed" id="generarCodePag" data-toggle="collapse" data-target="#collapseTres" aria-expanded="false" aria-controls="collapseTres">
                          YAPE/BCP
                        </button>
                      </h5>
                    </div>
                    <div id="collapseTres" class="collapse" aria-labelledby="headingThree" data-parent="#accordion">
                      <div class="card-body text-center">
                        <img src="images/YapeE.jpeg">
                      </div>
                      <div class="col-12 text-center">
                        <p class="text-black">Ingresa a Yape desde tu celular,<br>
                        Escanea este código QR,<br>
                        o haz el pago al número<br>
                        934896605<br>
                        agregándolo como contacto.<br>

                        Ingresa el siguiente monto a transferir<br>
                        S/<?php echo number_format($datosUsuario[2],2,'.','');?><br>
                        Añade este código<br>
                        <input type="text" class="text-center" id="codigoPag" readonly="true"><br>
                        Como nota y dale Pagar.<br></p>
                        <br>
                        <form action="/insertarpago.php" method="POST">
                          <button class="btn block-black" type="submit">Finalizar</button>
                        </form>
                      </div>
                      <br>
                    </div>
                  </div>
                  <div class="card">
                    <div class="card-header" id="headingThree">
                      <h5 class="mb-0 text-center">
                        <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseCuatro" aria-expanded="false" aria-controls="collapseCuatro">
                          DEPOSITO BANCARIO
                        </button>
                      </h5>
                    </div>
                    <div id="collapseCuatro" class="collapse" aria-labelledby="headingThree" data-parent="#accordion">
                      <div class="card-body text-black text-center">
                        Método de Pago: DEPÓSITO / TRANSFERENCIA <br>

                        Nombre / Razón Social: Aimar Fabrizio Dias Orrillo<br>

                        Banco: Banco de Crédito<br>

                        Número de cuenta: 19497347559065<br>

                        Código Interbancario (Entidad-Oficina-Cuenta-CC): 00219419734755906596<br>

                        Monto: S/<?php echo number_format($datosUsuario[2],2,'.','');?> <br>

                        Correo: universofsw.25021999@gmail.com<br>

                        Teléfono: 934896605<br>

                        Instrucciones: Enviar comprobante de pago respondiendo al correo de notificación de pedido o enviar a universofsw.25021999@gmail.com indicando en asunto el código de referencia del pedido. Otras formas de pago: Transferencia vía BCP a la cuenta 19497347559065/CCI 00219419734755906596. Yape al número 934896605. Cuentas a nombre de Aimar Fabrizio Dias Orrillo. Recuerda que si realizas un depósito en ventanilla, deberás añadir al monto de tu pedido la comisión que cobra el banco (7 soles apróx.). No olvides enviar el comprobante de pago por correo. Tu llegará en un plazo de 3 días hábiles, pero si lo necesitas con urgencia comunícate con nosotros para poder ayudarte.

                        Puedes contactarte con nosotros para cualquier información adicional:<br>


                       (+51) 934896605<br>

                       universofsw.25021999@gmail.com<br>
                       <br>
                       <form action="/insertarpago.php" method="POST">
                       <button class="btn block-black">Finalizar</button>
                        </form>
                       <br>
                      </div>
                    </div>
                  </div>
                </div>
                <!--==============================-->
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>
    </div>


    <div class="header__menu">
      <a href="https://instagram.com/fsw.universo?r=nametag"><i class="icon-instagram"></i></a>
            <ul>
                <p>Sigueme en</p>
                <li><a href="https://instagram.com/fsw.universo?r=nametag">@fsw.universo</a></li>
            </ul>
        </div>

    <div class="gallery-container">
      <div class="gallery-item">
        <img id="gallery-item-index" src="images/item-1-1-1.jpg">
      </div>
      <div class="gallery-item">
        <img id="gallery-item-index" src="images/item-1-1-2.jpg">
      </div>
      <div class="gallery-item">
        <img id="gallery-item-index" src="images/item-1-1-3.jpg">
      </div>
      <div class="gallery-item">
        <img id="gallery-item-index" src="images/item-1-1-4.jpg">
      </div>
    </div>


<?php include('./layoust/foot.php'); ?>

<script>
	var productoFinal ="EYELEVATION";
	var descripcionFinal = "descripcion";

  		$('#buyButton').on('click', function(e) {
      nombre_productoFinal = document.getElementById('nombre_productoFinal').value;
      nombre_descripcionFinal = document.getElementById('nombre_descripcionFinal').value;
  		Culqi.publicKey = 'sk_test_ed65d82ad369932e';

      Culqi.options({
          style: {
            logo: 'https://i.imgur.com/pSTKIRI.png',
            maincolor: '#000',
            buttontext: '#ffffff',
            maintext: '#4A4A4A',
            desctext: '#4A4A4A'
          }
      });

  		Culqi.settings({
		    title: productoFinal,
		    currency: 'PEN',
		    description: descripcionFinal,
		    amount: '<?php echo number_format($datosUsuario[2],2,'.','')*100;?>'
		 });
		    // Abre el formulario con la configuración en Culqi.settings
		    Culqi.open();
		    e.preventDefault();
		});

		function culqi() {

		  if (Culqi.token) { // ¡Objeto Token creado exitosamente!
		      var token = Culqi.token.id;
		      //En esta linea de codigo debemos enviar el "Culqi.token.id"
		      //hacia tu servidor con Ajax
          $.ajax({
            url:'thankyou.php',
            type:'POST',
            data:{

            }
          })
		  } else { // ¡Hubo algún problema!
		      // Mostramos JSON de objeto error en consola
		      console.log(Culqi.error);
		      alert(Culqi.error.user_message);
		  }
		};

	</script> 


  <script>
    $("#generarCodePag").click(function(){
      
      var num = Math.floor( Math.random()*900000000)+100000000;
      $("#codigoPag").val(num)
    });
  </script>
